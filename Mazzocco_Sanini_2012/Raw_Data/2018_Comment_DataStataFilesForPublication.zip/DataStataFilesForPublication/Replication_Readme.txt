To replicate Standard test of efficient risk sharing, run the do-file in the directory:  
~ /DataStataFilesForPublication/StataFilesForPublication/StandardTest.do

Replication code to check the sensitivity of standard efficient risk sharing test results to testing methods and consumption category is provided in StandardTest.do from Line 430. 



